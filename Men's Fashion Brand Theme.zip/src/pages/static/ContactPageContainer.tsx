import { ContactPage } from '../../components/pages/ContactPage';

export function ContactPageContainer() {
  return <ContactPage />;
}
