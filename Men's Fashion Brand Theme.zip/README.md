
  # Men's Fashion Brand Theme

  This is a code bundle for Men's Fashion Brand Theme. The original project is available at https://www.figma.com/design/H4k5hKpwNkdr7ddW8wEaZ9/Men-s-Fashion-Brand-Theme.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  